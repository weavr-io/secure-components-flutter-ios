//
//  components.h
//  components
//
//  Created by Tareq on 12/4/22.
//

#import <Foundation/Foundation.h>


//! Project version number for components.
FOUNDATION_EXPORT double componentsVersionNumber;

//! Project version string for components.
FOUNDATION_EXPORT const unsigned char componentsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <components/PublicHeader.h>

//#import <PSA/PSA.h>
//#import <PSA/ResourceProvider.h>
//#import <PSA/PSASharedStatuses.h>
//#import <PSA/PSATenant.h>
